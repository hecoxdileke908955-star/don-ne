import React from 'react';
import Link from 'next/link';

export const AdminSidebar: React.FC = () => {
  return (
    <aside className="w-64 border-r border-gray-200 bg-white p-4 flex flex-col justify-between min-h-screen">
      <div className="space-y-6">
        {/* Brand */}
        <div className="flex items-center gap-2 px-2">
          <span className="text-lg font-black text-primary">DỌN NÈ CMS</span>
          <span className="rounded bg-primary-soft px-1.5 py-0.5 text-[9px] font-bold text-primary">
            v1.0
          </span>
        </div>

        {/* Menu Navigation */}
        <nav className="space-y-1 text-xs">
          <Link
            href="/admin"
            className="flex items-center gap-2 rounded-ctrl px-3 py-2 font-semibold text-text-main hover:bg-surface-secondary"
          >
            📊 Tổng Quan Dashboard
          </Link>
          <Link
            href="/admin/leads"
            className="flex items-center gap-2 rounded-ctrl px-3 py-2 font-semibold text-text-main hover:bg-surface-secondary"
          >
            👥 Quản Lý Lead CRM
          </Link>
          <Link
            href="/admin/pricing"
            className="flex items-center gap-2 rounded-ctrl px-3 py-2 font-semibold text-text-main hover:bg-surface-secondary"
          >
            💰 Bảng Giá (Single Source)
          </Link>
          <Link
            href="/admin/editor/home"
            className="flex items-center gap-2 rounded-ctrl px-3 py-2 font-semibold text-text-main hover:bg-surface-secondary"
          >
            🎨 Visual Page Editor
          </Link>
          <Link
            href="/admin/services"
            className="flex items-center gap-2 rounded-ctrl px-3 py-2 font-semibold text-text-main hover:bg-surface-secondary"
          >
            🛠 Dịch Vụ & Danh Mục
          </Link>
          <Link
            href="/admin/settings"
            className="flex items-center gap-2 rounded-ctrl px-3 py-2 font-semibold text-text-main hover:bg-surface-secondary"
          >
            ⚙️ Cấu Hình Toàn Cục (Settings)
          </Link>
        </nav>
      </div>

      <div className="border-t border-gray-100 pt-3 text-[11px] text-text-muted">
        <p>Đăng nhập: <strong>SUPER_ADMIN</strong></p>
        <Link href="/" className="mt-1 block text-primary hover:underline font-semibold">
          ← Ra Website Công Khai
        </Link>
      </div>
    </aside>
  );
};
